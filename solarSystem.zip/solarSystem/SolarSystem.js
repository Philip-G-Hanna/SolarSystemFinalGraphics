$(document).ready(function(){
    $("canvas").fadeIn(3000);
});